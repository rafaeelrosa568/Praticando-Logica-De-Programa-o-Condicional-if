/*7 – Faça um programa que receba 13 notas, calcule e 
 * mostre a média aritmética entre elas. 
 * (faça usando repetição determinada – while)
 */
package PraticandoLogicaDeProgramacaoCondicional_if;
import java.util.Scanner;
public class Questao07 {
    public static void main(String[] args) {
        
        double nota;
        double media = 0;
        double soma = 0;
        int contador = 1;
        int cont;
        
        Scanner teclado = new Scanner(System.in);
        while (contador <=13) 
        {
            System.out.println("Informe sua nota");
            System.out.println("Digite a " +contador + "º nota");
            nota = teclado.nextDouble(); 
            soma = soma + nota;
            media = soma/contador;
            contador++;
            System.out.println("                     ");
            System.out.println("Sua nota é "+ media);
        }
    }
}

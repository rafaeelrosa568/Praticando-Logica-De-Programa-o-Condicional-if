/*
5 – Entre com 10 números e mostre o triplo de cada número. 
(faça usando repetição determinada – while)
*/
package PraticandoLogicaDeProgramacaoCondicional_if;

import java.util.Scanner;


public class Questao05 {
    
    public static void main(String[] args) {
        
        double numero1;
        double triplo;
        int contador = 1;
        
        Scanner teclado = new Scanner(System.in);
        
        while ( contador <= 10)
        {
            System.out.println("Digite 10 números");
            System.out.println("Informe o " +contador +"º número");
            numero1 = teclado.nextDouble();
            
            triplo = numero1 * 3;
            System.out.println("O triplo do "+ numero1 + " e "+ triplo);
            contador = contador + 1;
            System.out.println("Obrigado!!");
            
        }
    }
}

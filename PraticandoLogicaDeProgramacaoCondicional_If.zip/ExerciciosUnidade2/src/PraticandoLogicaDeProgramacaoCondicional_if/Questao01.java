//* 1– Faça um programa que receba dois números e 
//*mostre o maior.(condicional -if)
package PraticandoLogicaDeProgramacaoCondicional_if;

import java.util.Scanner;


public class Questao01 {

    
    public static void main(String[] args) {
         // Declaração de variavéis
       int numero;
       Scanner teclado = new Scanner (System.in);
       // Entrada de dados
        System.out.println("Digite um número:");
        numero = teclado.nextInt();
        //Processamento de dados
        if (numero > 0) { 
            System.out.println("O número " + 
                    numero + " é maior que zero!");
        }
        
        
    }
}

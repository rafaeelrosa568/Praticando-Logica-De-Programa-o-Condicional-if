/*
 *Faça um programa que receba dois números e execute as opções abaixo, 
 *de acordo com a escolha do usuário: (faça usando a condicional – switch)
 *1 – Média entre os números digitados 
 *2 – Produto (multiplicação) entre os números digitados 
 *3 – Divisão do primeiro pelo segundo 
 *4 – Diferença do maior pelo menor
 *Se a opção digitada for inválida, mostre uma mensagem de erro.
 */
package PraticandoLogicaDeProgramacaoCondicional_if;

import java.util.Scanner;


public class Questao03 {
    
    public static void main(String[] args) {
        double numero1, numero2;
        int opcao;
        Scanner teclado = new Scanner (System.in);
        System.out.println("Digite o 1º número: ");
        numero1 = teclado.nextDouble();
        System.out.println("Digite o 2º número: ");
        numero2 = teclado.nextDouble();
        
        System.out.println("Escolha as opções: ");
        System.out.println("1 para média entre os números digitados");
        System.out.println("2 para multiplicação entre os números digitados");
        System.out.println("3 para divisão do primeiro pelo segundo");
        System.out.println("4 para diferença do maior pelo menor");
        opcao = teclado.nextInt();
        switch (opcao)
        {
            case 1:System.out.println("Media dos números: " 
                    + numero1 + numero2 / 2); break;
            case 2:System.out.println("multiplicação " + numero1 * numero2);break;
            case 3:System.out.println("Divisão " + numero1 / numero2);break;
            case 4:System.out.println("A diferença do maior pelo meno " +
                    numero1 % numero2);break;
            
        }
    }
    
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PraticandoLogicaDeProgramacaoCondicional_if;

import java.util.Scanner;

/**
 *
 * @author Natállia Rosa
 */
public class Questao06 {
    
    public static void main(String[] args) {
        
        int numero, soma;
        int contador;
        
        Scanner teclado = new Scanner(System.in);
        
        for (contador =1; contador <=12; contador++)
        {
            System.out.println("Digite 12 números inteiros");  
            System.out.println("Informe o "+ contador + "º número");
            numero = teclado.nextInt();
            
            soma = numero + numero;
            System.out.println("A soma dos números digitados é: "+ soma);
        }
        
    }
}

//*2-Faça um programa que receba o salário de um funcionário, se o salário for 
//8maior ou igual a R$ 1.000,00, mostre o salário mais R$ 100,00 de bônus, 
//se for menor do que R$ 1.000,00, o bônus será de R$ 50,00.Mostre o novo 
//*salário(condicional –if...else)
package PraticandoLogicaDeProgramacaoCondicional_if;

import java.util.Scanner;

public class Questao02 {
    
    public static void main(String[] args) {
         //Declaração de variaveis
        Double salario, bonus;
        Scanner teclado = new Scanner (System.in);
        //Entrada de dados
        System.out.println("Informe o valor do salário: ");
        salario = teclado.nextDouble();
        //processamento de dados
        if (salario >= 1000) {
            //saída de dados
            System.out.println("O salário mais bônus de 100,00 valor total = " + 
                (salario + 100));
        } else {
            System.out.println("O salário mais bônus de 50,00 valor total = " +
                (salario + 50));
            
            
        
        }
           
    }
    
}

